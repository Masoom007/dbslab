﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System;
using System.Globalization;
using System.Text.RegularExpressions;
using Oracle.DataAccess.Types;
using Oracle.DataAccess.Client;



namespace ADMIN
{
    public partial class Form2 : Form
    {
        String finalString;
        public Form2()
        {
            this.BackgroundImage = Properties.Resources.i1;
            InitializeComponent();
        }
         OracleConnection conn;
        OracleCommand comm;
        OracleDataAdapter da;
        DataSet ds;
        DataTable dt;
        DataRow dr;
        int i = 0;
        public void connect1()
        {
            String oradb = "DATA SOURCE=desktop-v82ifm3;PERSIST SECURITY INFO=True;USER ID=system;Password=jarvis07";
            conn = new OracleConnection(oradb); // C#
            conn.Open();
        }

        private void button1_Click(object sender, EventArgs e)
        {
          
        }

        private void button2_Click(object sender, EventArgs e)
        {

        }

        private void textBox3_TextChanged(object sender, EventArgs e)
        {
            
        }
       
        private void textBox1_TextChanged(object sender, System.EventArgs e)
        {
            
        }

        private void textBox2_TextChanged(object sender, System.EventArgs e)
        {
              string test = textBox2.Text;
              bool allDigits= test.All(char.IsDigit);
              if(allDigits==false)
            {
                  MessageBox.Show("Enter Valid Phone Number");
              }
              
        }

        private void button2_Click_1(object sender, System.EventArgs e)
        {

            string email = textBox3.Text;
            Regex regex = new Regex(@"^([\w\.\-]+)@([\w\-]+)((\.(\w){2,3})+)$");
            Match match = regex.Match(email);
            if (match.Success)
            {

            }

            else
                MessageBox.Show(email + " is incorrect");
            try
            {
                connect1();
                OracleCommand cm = new OracleCommand();
                cm.Connection = conn;
                cm.CommandText = "insert into flightnames (c_name,phone_no,email_id,headoffice,password) values ('" + textBox1.Text + "' , " + textBox2.Text + ",'" + textBox3.Text + "','"+textBox4.Text+"','"+finalString +"')";
               
                // if the type is varchar preceede the value by quote '
                cm.CommandType = CommandType.Text;
                cm.ExecuteNonQuery();
                MessageBox.Show("Inserted!");
                conn.Close();
            }
            catch (Exception esp)
            {
                MessageBox.Show("Caught"+esp);
            }
        }

        private void button1_Click_1(object sender, System.EventArgs e)
        {
            var chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";
            var stringChars = new char[5];

            var random = new Random();

            for (int i = 0; i < stringChars.Length; i++)
            {
                stringChars[i] = chars[random.Next(chars.Length)];
            }
            finalString = new String(stringChars);
            MessageBox.Show(finalString);
        }

        private void Form2_Load(object sender, System.EventArgs e)
        {

        }
}

}




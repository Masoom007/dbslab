﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Oracle.DataAccess.Client;
using Oracle.DataAccess.Types;

namespace ADMIN
{
    public partial class Form3 : Form
    {
        OracleConnection conn;
        OracleCommand c;
        public Form3()
        {
            this.BackgroundImage = Properties.Resources.i1;
            InitializeComponent();
        }

        private void connect()
        {
            String oradb = "DATA SOURCE=desktop-v82ifm3;PERSIST SECURITY INFO=True;USER ID=system;Password=jarvis07";
            conn = new OracleConnection(oradb);
            c = new OracleCommand();
            c.Connection = conn;
            c.CommandType = CommandType.Text;

            conn.Open();
        }

        private void Form3_Load(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                connect();
                c.CommandText = "delete from flight where company='"+textBox1.Text+"'"; 
                c.ExecuteNonQuery();

                MessageBox.Show("All flight for "+textBox1.Text+" are removed.");
                conn.Close();
            }
            catch (Exception e1)
            {
                MessageBox.Show(e1.Message);
            }
        }
    }
}

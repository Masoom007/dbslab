﻿using Oracle.DataAccess.Client;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ADMIN
{
    public partial class Rfeedback : Form
    {

        OracleConnection cn;
        public Rfeedback()
        {
            this.BackgroundImage = Properties.Resources.i1;
            InitializeComponent();
            try
            {
                connect();
                OracleCommand cmd = new OracleCommand("select sender,dt,message from feedback", cn);
                cn.Open();
                cmd.CommandType = CommandType.Text;
                DataTable dt = new DataTable();
                OracleDataAdapter da = new OracleDataAdapter();
                da.SelectCommand = cmd;
                da.Fill(dt);
                dataGridView1.DataSource = dt;
                cn.Close();
            }
            catch (Exception e1)
            {
                MessageBox.Show(e1.Message);
            }
        }

        public void connect()
        {
            String oradb = "DATA SOURCE=desktop-v82ifm3;PERSIST SECURITY INFO=True;USER ID=system;Password=jarvis07";
            cn = new OracleConnection(oradb);
        }
        private void Rfeedback_Load(object sender, EventArgs e)
        {

        }
    }
}

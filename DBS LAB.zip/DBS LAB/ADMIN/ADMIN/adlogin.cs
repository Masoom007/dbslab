﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Oracle.DataAccess.Client;
using Oracle.DataAccess.Types;

namespace ADMIN
{
    public partial class adlogin : Form
    {
        OracleConnection conn;
        OracleCommand c;

        public adlogin()
        {
            this.BackgroundImage = Properties.Resources.i1;
            InitializeComponent();
        }

        private void adlogin_Load(object sender, EventArgs e)
        {

        }

        private void connect()
        {
            String oradb = "DATA SOURCE=desktop-v82ifm3;PERSIST SECURITY INFO=True;USER ID=system;Password=jarvis07";
            conn = new OracleConnection(oradb);
            c = new OracleCommand();
            c.Connection = conn;
            c.CommandType = CommandType.Text;

            conn.Open();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                var username = (usernametext.Text);
                String pass = passwordtext.Text;
                connect();
                OracleCommand cmd = new OracleCommand();
                cmd.Connection = conn;
                cmd.CommandText = "select * from adminlogin where username = '" + usernametext.Text + "' and password ='" + passwordtext.Text + "'";
                cmd.CommandType = CommandType.Text;
                OracleDataAdapter ad = new OracleDataAdapter(cmd.CommandText, conn);
                DataSet ds = new DataSet();
                ad.Fill(ds);
                int t = ds.Tables[0].Rows.Count;
                if (t == 1)
                {

                    new Form1().Show();
                    this.Hide();
                }

                else
                    MessageBox.Show("Invalid UserName/Password");
                conn.Close();
            }
            catch (Exception e1) 
            {
                MessageBox.Show(e1.Message);
            }
        }
    }
}

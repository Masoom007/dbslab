﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Oracle.DataAccess.Client;
using Oracle.DataAccess.Types;


namespace Flight
{
    public partial class Form1 : Form
    {
        
        bool t = false;
        public Form1()
        {
            this.BackgroundImage = Properties.Resources.i1;
            InitializeComponent();
                 }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            
        }
        private void textBox1_leave(object sender, EventArgs e)
        {
            if (textBox1.Text == "")
            {
                textBox1.Text = "No. of Children";
                textBox1.ForeColor = Color.Silver;
            }
            else
                textBox1.ForeColor = Color.Black;
        }
        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }
        private void textBox2_leave(object sender, EventArgs e)
        {
            if (textBox2.Text == "")
            {
                textBox2.Text = "No. of Adults";
                textBox2.ForeColor = Color.Silver;
            }
            else
                textBox2.ForeColor = Color.Black;
        }

        private void textBox2_Click(object sender, EventArgs e)
        {
            if (textBox2.Text == "No. of Adults")
                textBox2.Text = "";
            textBox2.ForeColor = Color.Black;
        }

        private void textBox1_Click(object sender, EventArgs e)
        {
            if (textBox1.Text == "No. of Children")
                textBox1.Text = "";
            textBox1.ForeColor = Color.Black;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                t = true; String trip;
                if (comboBox1.Text == "" || comboBox2.Text == "" || comboBox3.Text == "" || dateTimePicker1.Text == "" || textBox1.Text == "No. of Children" || textBox2.Text == "No. of Adults" || (!radioButton1.Checked && !radioButton2.Checked))
                {
                    MessageBox.Show("Fill all the details");
                    t = false;
                }

                else if (comboBox1.Text == comboBox2.Text)
                {
                    MessageBox.Show("Arrival and destination place are same");
                    t = false;
                }
                else if (Convert.ToInt32(textBox1.Text) < 0 || Convert.ToInt32(textBox2.Text) < 0)
                {
                    t = false;
                    MessageBox.Show("Invalid number for Children or Adults");
                }
                if (t == true)
                {
                    String d = comboBox1.Text;
                    String a = comboBox2.Text;
                    String c = comboBox3.Text;
                    String nc = textBox1.Text;
                    String na = textBox2.Text;
                  //  String date = dateTimePicker1.Text;
                 
                    String  date = dateTimePicker1.Value.Date.ToString("dd-MMM-yyyy");
                    String date1 = dateTimePicker2.Value.Date.ToString("dd-MMM-yyyy");
                    if (radioButton1.Checked )
                    {
                        trip = radioButton1.Text;
                        form2 f = new form2(a, d, c, nc, na, date,date1 , trip);
                        this.Hide();
                        f.Show();
                    }
                    else
                    {
                        if (dateTimePicker2.Value > dateTimePicker1.Value)
                        {
                            trip = radioButton2.Text;
                            if (radioButton1.Checked)
                            {
                                form2 f = new form2(a, d, c, nc, na, date, trip);
                                this.Hide();
                                f.Show();
                            }
                            else
                            {
                                new form2(a, d, c, nc, na, date, date1,trip).Show();
                                this.Hide();
                                
                            }
                        }
                        else
                            MessageBox.Show("Invalid return date");
                    }
                }

            }
            catch (Exception e1)
            {
                MessageBox.Show(e1.Message);
            }
        }

        private void label6_Click(object sender, EventArgs e)
        {

        }

        private void comboBox3_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            new feedback().Show();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            new Form6().Show();
        }
    }
}
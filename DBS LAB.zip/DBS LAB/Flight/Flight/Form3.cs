﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Oracle.DataAccess.Client;
using Oracle.DataAccess.Types;

namespace Flight
{   
    
    public partial class Summary : Form
    {
        OracleConnection conn;
        OracleCommand c;
        String returndate; String returnflightno; String rcomp, h1, m1, h2, m2;
        bool f = true;
        String a, d, cl, nc, na, trip, date, flightno, comp, cost;
       
        private void label11_Click(object sender, EventArgs e)
        {

        }
        private void connect()
        {
            String oradb = "DATA SOURCE=desktop-v82ifm3;PERSIST SECURITY INFO=True;USER ID=system;Password=jarvis07";
            conn = new OracleConnection(oradb);
            c = new OracleCommand();
            c.Connection = conn;
            c.CommandType = CommandType.Text;

            conn.Open();
        }

        int t = 0;
        private void button1_Click(object sender, EventArgs e)
        {
            this.Hide();
            new login(a, d, cl, nc, na, trip, date, flightno, comp, cost,returndate,returnflightno,rcomp,h1,m1,h2,m2).Show();

        }

        private void button3_Click(object sender, EventArgs e)
        {
            if (t == 0)
            {
                label2.Text += ": " + a;
                label3.Text += ": " + d;
                label4.Text += ": " + na;
                label5.Text += ": " + nc;
                label7.Text += ": " + c;
                label6.Text += ": " + flightno;
                t = 1;
            }
           
        }

        private void button2_Click(object sender, EventArgs e)
        {
            new Form1().Show();
            this.Hide();
        }

        public Summary(String a, String d, String cl, String nc, String na, String date, String trip,String flightno,String comp,String cost,String returndate,String returnflightno,String rcomp,String h1,String m1,String h2,String m2)
        {
            this.BackgroundImage = Properties.Resources.i1;
            InitializeComponent();
            this.a = a;
            this.d = d;
            this.cl = cl;
            this.nc = nc;
            this.na = na;
            this.trip = trip;
            this.date = date;
            this.comp = comp;
            this.flightno = flightno;
            this.cost = cost;
            this.returndate = returndate;
            this.returnflightno = returnflightno;
            this.rcomp = rcomp;
            this.h1 = h1;
            this.h2 = h2;
            this.m2 = m2;
            this.m1 = m1;
            //Economy
//Business
            if(cl=="Business"){
            int x=Convert.ToInt32(cost);
                x=x*2;
                cost = x.ToString();
            }
            if (t == 0)
            {
                label2.Text += ": " + a;
                label3.Text += ": " + d;
                label4.Text += ": " + na;
                label5.Text += ": " + nc;
                label7.Text += ": " + cl;
                label6.Text += ": " + flightno;
                label8.Text += ": " + cost;
                label9.Text += ": " + date.Substring(0,10);
                label12.Text +=": "+ comp;
                label14.Text +=":- "+ h1 + ":" + m1+" hours";
                if(trip=="Round Trip")
                {
                    label10.Text = "RETURN FLIGHT NO: " + returnflightno;
                    label11.Text = "RETURN DATE: " + returndate;
                    label13.Text = "RETURN COMPANY:" + rcomp;
                    label15.Text = "RETURN TIME:- " + h2 + ":" + m2+" hours";
                    label16.Text = "ARRIVAL " + ": " + d;
                    label17.Text = "DEPARTURE " + ": " +  a;
                }
                t = 1;

            }

        }

        private void Form3_Load(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {
            label2.Text += ":" + a;
        }
    }
}

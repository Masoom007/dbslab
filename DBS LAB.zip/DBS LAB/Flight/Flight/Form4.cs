﻿using Oracle.DataAccess.Client;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Flight
{
    public partial class payment : Form
    {
        String cost, a, d, cl, nc, na, date, trip, flightno, comp, returndate, returnflightno, rcomp, h1, m1, h2, m2;
       // String cost;
        String user;
        OracleConnection conn;
        OracleCommand c;
        
        public payment(String a, String d, String cl, String nc, String na, String date, String trip, String flightno, String comp, String cost, String returndate, String returnflightno, String rcomp, String h1, String m1, String h2, String m2,String user)
        {
            this.BackgroundImage = Properties.Resources.i1;
            this.a = a;
            this.d = d;
            this.cl = cl;
            this.nc = nc;
            this.na = na;
            this.trip = trip;
            this.date = date;
            this.comp = comp;
            this.flightno = flightno;
            this.cost = cost;
            this.returndate = returndate;
            this.returnflightno = returnflightno;
            this.rcomp = rcomp;
            this.h1 = h1;
            this.h2 = h2;
            this.m2 = m2;
            this.m1 = m1;
            this.user = user;
            if(cl=="Business")
            {
                int x=Convert.ToInt32(cost)*2;
                cost = x.ToString();
            }

           // this.cost = cost;
            InitializeComponent();
            label2.Text += " Rs. "+cost;
        }
        
        private void payment_Load(object sender, EventArgs e)
        {
        }
        private void connect()
        {
            String oradb = "DATA SOURCE=desktop-v82ifm3;PERSIST SECURITY INFO=True;USER ID=system;Password=jarvis07";
            conn = new OracleConnection(oradb);
            c = new OracleCommand();
            c.Connection = conn;
            c.CommandType = CommandType.Text;

            conn.Open();
        }
        private void button1_Click(object sender, EventArgs e)
        {
            if (textBox1.Text != "" && textBox2.Text != "")
            {
                try
                {
                    connect();
                    MessageBox.Show("PAYMENT SUCCESSFUL" + "\n" + flightno + "\n" + returnflightno);
                    c = new OracleCommand("updateticket", conn);
                    c.CommandType = CommandType.StoredProcedure;
                    String tid = "tid" + user.Substring(0, 2) + flightno;
                    //MessageBox.Show(date);
                    date = date.Substring(0,10);
                   // MessageBox.Show(date);
                    c.Parameters.Add("tid", OracleDbType.Varchar2).Value = tid;
                    c.Parameters.Add("comp", OracleDbType.Varchar2).Value = comp;
                    c.Parameters.Add("arr", OracleDbType.Varchar2).Value = a;
                    c.Parameters.Add("dest", OracleDbType.Varchar2).Value = d;
                    c.Parameters.Add("na", OracleDbType.Int32).Value = Convert.ToInt32(na);
                    c.Parameters.Add("nc", OracleDbType.Int32).Value = Convert.ToInt32(nc);
                    c.Parameters.Add("fno", OracleDbType.Varchar2).Value = flightno;
                    c.Parameters.Add("d", OracleDbType.Varchar2).Value = date;
                    c.Parameters.Add("t", OracleDbType.Varchar2).Value = h1+":"+m1;
                    c.Parameters.Add("c", OracleDbType.Int32).Value = Convert.ToInt32(cost);
                    c.Parameters.Add("class1", OracleDbType.Varchar2).Value = cl;
                    c.Parameters.Add("usname", OracleDbType.Varchar2).Value = user;

                    
                    c.ExecuteNonQuery();
                    conn.Close();
                    this.Hide(); new Form1().Show();
                }
                catch (Exception en1)
                {
                    MessageBox.Show(en1.Message);
                }
            }
            else MessageBox.Show("enter details");

        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Hide();
            new Form1().Show();
        }
    }
}

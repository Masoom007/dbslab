﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Oracle.DataAccess.Client;
using Oracle.DataAccess.Types;

namespace Flight
{
    public partial class login : Form
    {
        String user;
        OracleConnection conn;
        OracleCommand comm;
        String cost,a,d,cl,nc,na,date,trip,flightno,comp,returndate,returnflightno,rcomp,h1,m1,h2,m2;
        public login(String a, String d, String cl, String nc, String na, String date, String trip, String flightno, String comp, String cost, String returndate, String returnflightno, String rcomp, String h1, String m1, String h2, String m2)
        {
            this.a = a;
            this.d = d;
            this.cl = cl;
            this.nc = nc;
            this.na = na;
            this.trip = trip;
            this.date = date;
            this.comp = comp;
            this.flightno = flightno;
            this.cost = cost;
            this.returndate = returndate;
            this.returnflightno = returnflightno;
            this.rcomp = rcomp;
            this.h1 = h1;
            this.h2 = h2;
            this.m2 = m2;
            this.m1 = m1;
            InitializeComponent();

        }
        public void connect()
        {
            String oradb = "DATA SOURCE=desktop-v82ifm3;PERSIST SECURITY INFO=True;USER ID=system;Password=jarvis07";
            conn = new OracleConnection(oradb);
            conn.Open();
        }
        private void button2_Click(object sender, EventArgs e)
        {
            this.Hide();
            new signup(a, d, cl, nc, na, trip, date, flightno, comp, cost, returndate, returnflightno, rcomp, h1, m1, h2, m2).Show();
        }

        private void login_Load(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            user = textBox1.Text;
            if (textBox1.Text == "" || textBox2.Text == "")
            {
                MessageBox.Show("fill details");
            }
            else {
                try
                {
                    connect();
                    comm = new OracleCommand();
                    comm.CommandText = "select * from userlogin where username='" + textBox1.Text + "'and password='"+textBox2.Text+"'";

                    comm.CommandType = CommandType.Text;
                    DataSet ds = new DataSet();
                    OracleDataAdapter da = new OracleDataAdapter(comm.CommandText, conn);
                    da.Fill(ds);
                    //DataTable dt = ds.Tables["Tbl_userlogin"];
                    int t = ds.Tables[0].Rows.Count;
                    if(t==1)
                    {
                        MessageBox.Show("successful Login");
                        this.Hide();
                        new payment(a, d, cl, nc, na, trip, date, flightno, comp, cost, returndate, returnflightno, rcomp, h1, m1, h2, m2,user).Show();
                    }
                    else
                    {
                        MessageBox.Show("wrong username/password");

                    }

                   // MessageBox.Show(t.ToString());
                    conn.Close();
                    //String x = t.ToString();
                }
                catch (Exception E)
                {
                    MessageBox.Show("error"+E);
                 }

            }

        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Oracle.DataAccess.Client;
using Oracle.DataAccess.Types;

namespace Flight
{
    public partial class Form6 : Form
    {
        String tid, uname;
        OracleConnection conn;
        OracleCommand c;
        String cost;
        public Form6()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            tid = textBox2.Text;
            uname = textBox1.Text;
            int i = 0;
            if (tid != "" && uname != "")
            {
                try
                {
                    connect();
                    OracleCommand cm = new OracleCommand();
                    cm.Connection = conn;
                    //cm.CommandText = "insert into userlogin values('" + uname + "','" + pass + "','" + email + "')";
                    cm.CommandText = "select cost from ticket where uname = '" + uname + "' and tid = '" + tid + "'";
                    cm.CommandType = CommandType.Text;
                    OracleDataReader dr = cm.ExecuteReader();
                    dr.Read();
                    cost = dr.GetInt32(0).ToString();
                    i = 1;

                    // cm.ExecuteNonQuery();
                    //MessageBox.Show("Signed UP");
                    conn.Close();

                    this.Hide();
                }
                catch (Exception E)
                {
                    MessageBox.Show("Details not found in DataBase"  );
                    // new Form6().Show();
                }
                if (i == 1)
                {
                    try
                    {
                        connect();
                        OracleCommand cm = new OracleCommand();
                        cm.Connection = conn;
                        //cm.CommandText = "insert into userlogin values('" + uname + "','" + pass + "','" + email + "')";
                        cm.CommandText = "delete from ticket where uname = '" + uname + "' and tid = '" + tid + "'";
                        cm.CommandType = CommandType.Text;
                        cm.ExecuteNonQuery();
                        MessageBox.Show(cost + " Rupees refunded");
                        conn.Close();

                        this.Hide();
                    }
                    catch (Exception E)
                    {
                        MessageBox.Show("Details not found in DataBase");
                    }
                }
            }
            else
                MessageBox.Show("enter all details");

        }
        private void connect()
        {
            String oradb = "DATA SOURCE=desktop-v82ifm3;PERSIST SECURITY INFO=True;USER ID=system;Password=jarvis07";
            conn = new OracleConnection(oradb);
            c = new OracleCommand();
            c.Connection = conn;
            c.CommandType = CommandType.Text;

            conn.Open();
        }
    }
}

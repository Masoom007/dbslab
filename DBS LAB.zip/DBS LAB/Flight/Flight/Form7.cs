﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Oracle.DataAccess.Client;
using Oracle.DataAccess.Types;
//using System;
using System.Globalization;
using System.Text.RegularExpressions;

namespace Flight
{
    public partial class signup : Form
    {
        String cost, a, d, cl, nc, na, date, trip, flightno, comp, returndate, returnflightno, rcomp, h1, m1, h2, m2;
        bool invalid = false;
       // String cost;
        OracleConnection conn;
        OracleCommand comm;
        public void connect()
        {
            String oradb = "DATA SOURCE=desktop-v82ifm3;PERSIST SECURITY INFO=True;USER ID=system;Password=jarvis07";
            conn = new OracleConnection(oradb);
            conn.Open();
        }
        public signup(String a, String d, String cl, String nc, String na, String date, String trip, String flightno, String comp, String cost, String returndate, String returnflightno, String rcomp, String h1, String m1, String h2, String m2)
        {
            this.BackgroundImage = Properties.Resources.i1;
            this.a = a;
            this.d = d;
            this.cl = cl;
            this.nc = nc;
            this.na = na;
            this.trip = trip;
            this.date = date;
            this.comp = comp;
            this.flightno = flightno;
            this.cost = cost;
            this.returndate = returndate;
            this.returnflightno = returnflightno;
            this.rcomp = rcomp;
            this.h1 = h1;
            this.h2 = h2;
            this.m2 = m2;
            this.m1 = m1;
            InitializeComponent();
        }

        private void label3_Click(object sender, EventArgs e)
        {

        }
        private string DomainMapper(Match match)
        {
            // IdnMapping class with default property values.
            IdnMapping idn = new IdnMapping();

            string domainName = match.Groups[2].Value;
            try
            {
                domainName = idn.GetAscii(domainName);
            }
            catch (ArgumentException)
            {
                invalid = true;
            }
            return match.Groups[1].Value + domainName;
        }
        public bool IsValidEmail(string strIn)
        {
            invalid = false;
            if (String.IsNullOrEmpty(strIn))
                return false;

            // Use IdnMapping class to convert Unicode domain names.
            try
            {
                strIn = Regex.Replace(strIn, @"(@)(.+)$", this.DomainMapper,
                                      RegexOptions.None, TimeSpan.FromMilliseconds(200));
            }
            catch (RegexMatchTimeoutException)
            {
                return false;
            }

            if (invalid)
                return false;

            // Return true if strIn is in valid e-mail format.
            try
            {
                return Regex.IsMatch(strIn,
                      @"^(?("")("".+?(?<!\\)""@)|(([0-9a-z]((\.(?!\.))|[-!#\$%&'\*\+/=\?\^`\{\}\|~\w])*)(?<=[0-9a-z])@))" +
                      @"(?(\[)(\[(\d{1,3}\.){3}\d{1,3}\])|(([0-9a-z][-\w]*[0-9a-z]*\.)+[a-z0-9][\-a-z0-9]{0,22}[a-z0-9]))$",
                      RegexOptions.IgnoreCase, TimeSpan.FromMilliseconds(250));
            }
            catch (RegexMatchTimeoutException)
            {
                return false;
            }
        }
        private void button1_Click(object sender, EventArgs e)
        {
            if (textBox1.Text == "" || textBox2.Text == "" || textBox3.Text == "" || textBox4.Text == "")
            {
                MessageBox.Show("Please Fill Details");
            }
            
            if (!checkBox1.Checked)
            {
                MessageBox.Show("ACCEPT T&C");
            }
            if (!IsValidEmail(textBox4.Text))
            {
                MessageBox.Show("enter valid email id");
            }

            else
            {
                if (textBox2.Text != textBox3.Text)
                {
                    MessageBox.Show("passwords dont match");
                   
                }
                else
                {
                    String uname = textBox1.Text;
                    String pass = textBox2.Text;
                    String email = textBox4.Text;
                    try
                    {
                        connect();
                        OracleCommand cm = new OracleCommand();
                        cm.Connection = conn;
                        cm.CommandText = "insert into userlogin values('" + uname + "','" + pass + "','"+email+"')";
                        cm.CommandType = CommandType.Text;
                        cm.ExecuteNonQuery();
                        MessageBox.Show("Signed UP");
                        conn.Close();
                        new login(a, d, cl, nc, na, trip, date, flightno, comp, cost, returndate, returnflightno, rcomp, h1, m1, h2, m2).Show();
                        this.Hide();
                    }
                    catch (Exception E)
                    {
                        MessageBox.Show("username taken");
                    }
                }

            }
            
           

        }

        private void signup_Load(object sender, EventArgs e)
        {

        }
    }
}

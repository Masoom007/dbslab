﻿using Oracle.DataAccess.Client;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Net.Mail;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Flight
{
    public partial class feedback : Form
    {
        OracleConnection conn;
        OracleCommand c;
        Boolean bl;
        public feedback()
        {
            InitializeComponent();
        }

        private void feedback_Load(object sender, EventArgs e)
        {

        }

        private void connect()
        {
            String oradb = "DATA SOURCE=desktop-v82ifm3;PERSIST SECURITY INFO=True;USER ID=system;Password=jarvis07";
            conn = new OracleConnection(oradb);
            c = new OracleCommand();
            c.Connection = conn;
            c.CommandType = CommandType.Text;

            conn.Open();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            bl = true;
            if (textBox1.Text == "" || richTextBox1.Text == "")
            {
                MessageBox.Show("Complete the form");
                bl = false;
            }
            else
            {
                try
                {
                  //  String email = textBox1.Text;
                    var email = new MailAddress(textBox1.Text);
                    String feedback = richTextBox1.Text;
                    connect();
                    c.CommandText = "insert into feedback values('" + email + "','admin',sysdate,'" + feedback + "')";
                    c.ExecuteNonQuery();

                    MessageBox.Show("Thank you for Feedback !!");
                    conn.Close();

                }
                catch (Exception e1)
                {
                    MessageBox.Show(e1.Message);
                }
            }
        }
    }
}

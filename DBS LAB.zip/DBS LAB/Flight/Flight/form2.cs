﻿using Oracle.DataAccess.Client;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Oracle.DataAccess.Types;

namespace Flight
{
    public partial class form2 : Form
    {
        String a, d, c, nc, na, trip,date,comp,flightno,fdate,rdate;
        String returndate, rfn;
        int cost11, cost22;
        String h1, h2, m1, m2;
        String rcomp;
        private void button2_Click(object sender, EventArgs e)
        {
            this.Hide();
            new Form1().Show();
        }

        String cost = "5000";
        OracleConnection cn;
        public form2(String a, String d, String c, String nc, String na, String date, String trip)
        {
            InitializeComponent();
            this.a = a;
            this.d = d;
            this.c = c;
            this.nc = nc;
            this.na = na;
            this.trip = trip;
            this.date = date;

            try
            {
                connect();
                OracleCommand cmd = new OracleCommand("select * from flight where depart='" + d + "' and arr='" + a + "' and flightdate='" + date + "'", cn);
                cn.Open();
                cmd.CommandType = CommandType.Text;
                DataTable dt = new DataTable();
                OracleDataAdapter da = new OracleDataAdapter();
                da.SelectCommand = cmd;
                da.Fill(dt);
                dataGridView1.DataSource = dt;
                cn.Close();
            }
            catch (Exception e1)
            {
                MessageBox.Show(e1.Message);
            }
        }

        public form2(String a, String d, String c, String nc, String na,String date, String rdate, String trip)
        {
            InitializeComponent();
            this.a = a;
            this.d = d;
            this.c = c;
            this.nc = nc;
            this.na = na;
            this.trip = trip;
            this.date = date;
            returndate = rdate;
            try
            {
                connect();
                OracleCommand cmd = new OracleCommand("select company,Flight_no,Depart,Arrival,Fdate,class,priceadult,timehr,timemin,duration from flight where depart='" + d + "' and arrival='" + a + "' and fdate='" + date + "'", cn);
                cn.Open();
                cmd.CommandType = CommandType.Text;
                DataTable dt = new DataTable();
                OracleDataAdapter da = new OracleDataAdapter();
                da.SelectCommand = cmd;
                da.Fill(dt);
                dataGridView1.DataSource = dt;
                cn.Close();
                if (trip == "Round Trip")
                {
                    this.a = d;
                    this.d = a;
                    this.date = rdate;
                    connect();
                    cmd = new OracleCommand("select company,Flight_no,Depart,Arrival,Fdate,class,priceadult,timehr,timemin,duration from flight where depart='" + a + "' and arrival='" + d + "' and fdate='" + rdate + "'", cn);
                    cn.Open();
                    cmd.CommandType = CommandType.Text;
                    dt = new DataTable();
                    da = new OracleDataAdapter();
                    da.SelectCommand = cmd;
                    da.Fill(dt);
                    dataGridView2.DataSource = dt;
                    cn.Close();
                }
            }
            catch (Exception e1)
            {
                MessageBox.Show(e1.Message);
            }
        }

        public void connect()
        {
            String oradb = "DATA SOURCE=desktop-v82ifm3;PERSIST SECURITY INFO=True;USER ID=system;Password=jarvis07";
            cn = new OracleConnection(oradb);
        }
        private void form2_Load(object sender, EventArgs e)
        {
        }
        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
           
            foreach (DataGridViewRow row in dataGridView1.SelectedRows)
            {
                comp = row.Cells[0].Value.ToString();
                flightno = row.Cells[1].Value.ToString();
                 d = row.Cells[2].Value.ToString();
                 a = row.Cells[3].Value.ToString();
                 fdate = row.Cells[4].Value.ToString();
                 h1= row.Cells[7].Value.ToString();
                 m1= row.Cells[8].Value.ToString();
                String cost1 = row.Cells[6].Value.ToString();
                 cost11 = Convert.ToInt16(cost1);

                cost11 *= (Convert.ToInt16(na) + Convert.ToInt16(nc));
                //MessageBox.Show(value1+value2)
            }
            foreach (DataGridViewRow row in dataGridView2.SelectedRows)
            {
                rcomp = row.Cells[0].Value.ToString();
                rfn = row.Cells[1].Value.ToString();
                d = row.Cells[2].Value.ToString();
                a = row.Cells[3].Value.ToString();
          // returndate = row.Cells[4].Value.ToString("dd-MMM-yyyy");
               // c = row.Cells[6].Value.ToString();
                String cost2 = row.Cells[6].Value.ToString();
                h2 = row.Cells[7].Value.ToString();
                m2 = row.Cells[8].Value.ToString();
                //MessageBox.Show(value1+value2)
                cost22 = Convert.ToInt16(cost2);
                cost22 *= (Convert.ToInt16(na) + Convert.ToInt16(nc));
            }
            cost = (cost11 + cost22).ToString();
            this.Hide();
            new Summary(a, d, c, nc, na, fdate, trip, flightno, comp,cost,returndate,rfn,rcomp,h1,m1,h2,m2).Show();
        }
    }
}
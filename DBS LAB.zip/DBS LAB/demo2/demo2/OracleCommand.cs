﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace demo2
{
    class OracleCommand
    {
        public OracleConnection Connection { get; set; }

        public System.Data.CommandType CommandType { get; set; }

        public string CommandText { get; set; }
    }
}

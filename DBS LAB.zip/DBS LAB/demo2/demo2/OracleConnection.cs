﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace demo2
{
    class OracleConnection
    {
        private string oradb;

        public OracleConnection(string oradb)
        {
            // TODO: Complete member initialization
            this.oradb = oradb;
        }

        internal void Open()
        {
            throw new NotImplementedException();
        }
    }
}

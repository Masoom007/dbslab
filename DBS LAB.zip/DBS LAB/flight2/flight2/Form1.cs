﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Oracle.DataAccess.Client;
using Oracle.DataAccess.Types;
using System.Net.Mail;
using Microsoft.VisualBasic;
namespace flight2
{
    public partial class Form1 : Form
    {
        OracleConnection conn;
        DataTable dt;
        private void connect()
        {
            String oradb = "DATA SOURCE=desktop-v82ifm3;PERSIST SECURITY INFO=True;USER ID=system;Password=jarvis07";
            conn = new OracleConnection(oradb);
            conn.Open();
        }
        public Form1()
        {
            this.BackgroundImage = Properties.Resources.i1;
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
           try
            {
                var email = new MailAddress(textBox1.Text);
                String pass = textBox2.Text;
                connect();
                OracleCommand cmd = new OracleCommand();
                cmd.Connection = conn;
                cmd.CommandText="select * from fclogin where username = '" + textBox1.Text + "' and pass='"+textBox2.Text+"'";
                cmd.CommandType = CommandType.Text;
                OracleDataAdapter ad = new OracleDataAdapter(cmd.CommandText, conn);
                DataSet ds = new DataSet();
                ad.Fill(ds);
                int t=ds.Tables[0].Rows.Count;
                if (t == 1)
                {
        
                    p2 f = new p2(textBox1.Text);
                    f.Show();
                    this.Hide();
                }

                else
                    label3.Text = "Invalid UserName/Password";
                conn.Close();             
            }
            catch (Exception e1)
            {
                MessageBox.Show(e1.Message);
            }
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
         
            changepass p = new changepass();
            p.Show();
            this.Hide();
        }
    }
}

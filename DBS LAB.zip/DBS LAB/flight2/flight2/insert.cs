﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Oracle.DataAccess.Client;
using Oracle.DataAccess.Types;

namespace flight2
{
    public partial class insert : Form
    {
        OracleConnection conn;
        OracleCommand c;

        bool f = true;
        public insert(String s)
        {
            this.BackgroundImage = Properties.Resources.i1;
            InitializeComponent();
            connect();
            try
            {
                label15.Text = s;
                c.CommandText = "select name from companydisp where eid = '"+s+"'";
                c.CommandType = CommandType.Text;
                OracleDataReader dr = c.ExecuteReader();
                dr.Read();
                label15.Text = dr.GetString(0);
                conn.Close();
            }
            catch (Exception e1) {
                MessageBox.Show(e1.Message.ToString());
            }
        }
        private void connect()
        {
            String oradb = "DATA SOURCE=desktop-v82ifm3;PERSIST SECURITY INFO=True;USER ID=system;Password=jarvis07";
            conn = new OracleConnection(oradb);
            c = new OracleCommand();
            c.Connection = conn;
            c.CommandType = CommandType.Text;

            conn.Open();
        }

        private void insert_Load(object sender, EventArgs e)
        {
            
        }

        private void button1_Click(object sender, EventArgs e)
        {
            f = true;
            
            
            if (textBox1.Text=="" || textBox2.Text == "" || textBox3.Text == "" || textBox4.Text == "" || textBox6.Text == "")
            {
                MessageBox.Show("Fill all the details");
                f = false;
            }
            if((textBox2.Text.All(char.IsDigit) && textBox3.Text.All(char.IsDigit) && textBox4.Text.All(char.IsDigit)  && textBox6.Text.All(char.IsDigit))!=true)
            {
                MessageBox.Show("Invalid Values for some text fields");
                f=false;
            }
           if(f)
            {
                try
                {
                    connect();
                    String r = "";
                    if (comboBox3.Text == "YES")
                        r = "Y";
                    else
                        r = "N";
                    String date = dateTimePicker1.Value.Date.ToString("dd-MMM-yyyy");
            
                    
                    c.CommandText = "insert into flight values('" + label15.Text + "','" + textBox1.Text + "','" + comboBox1.Text + "','" + comboBox2.Text + "','" + date + "','"+r+ "'," + comboBox4.Text + "," +comboBox5.Text + "," + textBox2.Text + "," + textBox3.Text + "," + textBox4.Text + "," + comboBox6.Text + "," + textBox6.Text + ",NULL)";
                    c.ExecuteNonQuery();
                            
                    MessageBox.Show("Added");
                    conn.Close();
                    }
                catch (Exception e1)
                {
                    MessageBox.Show(e1.Message);
                }
            }
        }

        private void textBox6_TextChanged(object sender, EventArgs e)
        {

        }

        private void label14_Click(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void insert_ControlAdded(object sender, ControlEventArgs e)
        {

        }
    }
}

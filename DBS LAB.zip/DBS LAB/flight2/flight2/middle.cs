﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace flight2
{
    public partial class middle : Form
    {
        int t;
        public middle(int t)
        {
            InitializeComponent();
            this.t = t;
        }

        private void middle_Load(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (t == 2)
            {
                String date = dateTimePicker1.Value.Date.ToString("dd-MMM-yyyy");
                view v = new view(textBox1.Text, date);
                v.Show();
                this.Hide();
            }
            if (t == 1) 
            {
                String date = dateTimePicker1.Value.Date.ToString("dd-MMM-yyyy");
                modify v = new modify(textBox1.Text, date);
                v.Show();
                this.Hide();
            }
            if (t == 3) {
                String date = dateTimePicker1.Value.Date.ToString("dd-MMM-yy");
                passenger p1 = new passenger(textBox1.Text, date);
                p1.Show();
            
            }
        }
    }
}

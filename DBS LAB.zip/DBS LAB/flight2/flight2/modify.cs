﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Oracle.DataAccess.Client;
using Oracle.DataAccess.Types;

namespace flight2
{
    public partial class modify : Form
    {
        OracleConnection conn;
        OracleCommand c;

        bool f = true;
        String fno, date;
        public modify(String fno,String date)
        {
            this.BackgroundImage = Properties.Resources.i1;
            InitializeComponent();
            connect();
            this.fno = fno;
            this.date = date;
            try
            {
                c.CommandText = "select * from flight where flight_no = '" + fno + "' and fdate='" + date + "'";
                c.CommandType = CommandType.Text;
                OracleDataReader dr = c.ExecuteReader();
                dr.Read();
                label15.Text = dr.GetString(0);
                textBox1.Text = dr.GetString(1);
                comboBox1.Text = dr.GetString(2);
                comboBox2.Text = dr.GetString(3);
                //label19.Text = dr.GetDateTime(4).ToString("dd-MMM-yyyy");
                textBox2.Text = dr.GetInt32(8).ToString();
                textBox3.Text = dr.GetInt32(9).ToString();
                textBox4.Text = dr.GetInt32(10).ToString();
                comboBox6.Text = dr.GetInt32(11).ToString();
                comboBox3.Text = dr.GetString(5);
                comboBox4.Text = dr.GetInt32(6).ToString();
                comboBox5.Text = dr.GetInt32(7).ToString();
                textBox6.Text = dr.GetInt32(12).ToString();
                conn.Close();
            }
            catch (Exception e1)
            {
                MessageBox.Show(e1.Message.ToString());
            }
        }
        private void connect()
        {
            String oradb = "DATA SOURCE=desktop-v82ifm3;PERSIST SECURITY INFO=True;USER ID=system;Password=jarvis07";
            conn = new OracleConnection(oradb);
            c = new OracleCommand();
            c.Connection = conn;
            c.CommandType = CommandType.Text;

            conn.Open();
        }
        private void modify_Load(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            f = true;
            if (textBox1.Text == "" || textBox2.Text == "" || textBox3.Text == "" || textBox4.Text == "" || textBox6.Text == "")
            {
                MessageBox.Show("Fill all the details");
                f = false;
            }
            if ((textBox2.Text.All(char.IsDigit) && textBox3.Text.All(char.IsDigit) && textBox4.Text.All(char.IsDigit) && textBox6.Text.All(char.IsDigit)) != true)
            {
                MessageBox.Show("Invalid Values for some text fields");
                f = false;
            }
            if (f)
            {
                try
                {
                    connect();
                    String r = "";
                    if (comboBox3.Text == "YES")
                        r = "Y";
                    else
                        r = "N";

                    c.CommandText = "delete from flight where flight_no='"+fno+"'and fdate='"+date+"'";
                    c.ExecuteNonQuery();
                    c.CommandText = "insert into flight values('" + label15.Text + "','" + textBox1.Text + "','" + comboBox1.Text + "','" + comboBox2.Text + "','" + date + "','" + r + "'," + comboBox4.Text + "," + comboBox5.Text + "," + textBox2.Text + "," + textBox3.Text + "," + textBox4.Text + "," + comboBox6.Text + "," + textBox6.Text + ",NULL)";
                    c.ExecuteNonQuery();

                    MessageBox.Show("Updated");
                    conn.Close();
                }
                catch (Exception e1)
                {
                    MessageBox.Show(e1.Message);
                }
            }
        }
    }
}

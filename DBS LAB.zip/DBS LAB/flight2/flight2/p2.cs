﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic;
using Oracle.DataAccess.Client;

namespace flight2
{
    public partial class p2 : Form
    {
        String s;
        OracleConnection conn;
        OracleCommand c;
        public p2(String s1)
        {
           this.BackgroundImage = Properties.Resources.i1;
            InitializeComponent();
            s = s1;
        }

        private void connect()
        {
            String oradb = "DATA SOURCE=desktop-v82ifm3;PERSIST SECURITY INFO=True;USER ID=system;Password=jarvis07";
            conn = new OracleConnection(oradb);
            c = new OracleCommand();
            c.Connection = conn;
            c.CommandType = CommandType.Text;

            conn.Open();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            insert a = new insert(s);
            a.Show();
            
        }

        private void p2_Load(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            middle m1 = new middle(1);
            m1.Show();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            middle m1 = new middle(2);
            m1.Show();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            String c12=Microsoft.VisualBasic.Interaction.InputBox("Enter username !", "BlackList", "Default Text");
            try
            {
                connect();

                c.CommandText = "insert into blacklist values('"+c12+"')";
                c.ExecuteNonQuery();

                MessageBox.Show("Blacklisted !!");
                conn.Close();
            }
            catch (Exception e1)
            {
                MessageBox.Show(e1.Message);
            }
        }

        private void button5_Click(object sender, EventArgs e)
        {
            String c12 = Microsoft.VisualBasic.Interaction.InputBox("Enter customer username !", "REMOVE FROM BLACKLIST", "Default Text");
            try
            {
                connect();

                c.CommandText = "delete from blacklist where username='" + c12 + "'";
                c.ExecuteNonQuery();

                MessageBox.Show("Removed from blacklist !!");
                conn.Close();
            }
            catch (Exception e1)
            {
                MessageBox.Show(e1.Message);
            }
        }

        private void button6_Click(object sender, EventArgs e)
        {
            middle m1 = new middle(3);
            m1.Show();
        }
    }
}

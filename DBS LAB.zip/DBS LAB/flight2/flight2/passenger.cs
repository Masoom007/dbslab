﻿using Oracle.DataAccess.Client;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace flight2
{
    public partial class passenger : Form
    {
        public passenger(String fno,String date)
        {
            InitializeComponent();
            try
            {
                connect();
                MessageBox.Show(date);
                OracleCommand cmd = new OracleCommand("select username,email from userlogin where username in (select uname from ticket where flightno='" + fno + "' and tdate like '" + date + "%')", cn);
                cn.Open();
                cmd.CommandType = CommandType.Text;
                DataTable dt = new DataTable();
                OracleDataAdapter da = new OracleDataAdapter();
                da.SelectCommand = cmd;
                da.Fill(dt);
                dataGridView1.DataSource = dt;
                cn.Close();
            }
            catch (Exception e1)
            {
                MessageBox.Show(e1.Message);
            }
        }
        OracleConnection cn;
        private void passenger_Load(object sender, EventArgs e)
        {

        }

        public void connect()
        {
            String oradb = "DATA SOURCE=desktop-v82ifm3;PERSIST SECURITY INFO=True;USER ID=system;Password=jarvis07";
            cn = new OracleConnection(oradb);
        }
    }
}

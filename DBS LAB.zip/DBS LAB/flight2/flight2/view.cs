﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Oracle.DataAccess.Client;
using Oracle.DataAccess.Types;

namespace flight2
{
    public partial class view : Form
    {
        OracleConnection conn;
        OracleCommand c;

        bool f = true;
        public view(String fno,String date)
        {
            InitializeComponent();
            connect();
            try
            {
                c.CommandText = "select * from flight where flight_no = '" + fno + "' and fdate='"+date+"'";
                c.CommandType = CommandType.Text;
                OracleDataReader dr = c.ExecuteReader();
                dr.Read();
                label15.Text = dr.GetString(0);
                label16.Text=dr.GetString(1);
                label17.Text = dr.GetString(2);
                label18.Text = dr.GetString(3); 
                label19.Text = dr.GetDateTime(4).ToString("dd-MMM-yyyy");
                label20.Text = dr.GetInt32(8).ToString();
                label21.Text = dr.GetInt32(9).ToString();
                label22.Text = dr.GetInt32(10).ToString();
                label23.Text = dr.GetInt32(11).ToString();
                label24.Text = dr.GetString(5);
                label25.Text = dr.GetInt32(6).ToString();
                label26.Text = dr.GetInt32(7).ToString();
                label27.Text = dr.GetInt32(12).ToString();
                conn.Close();
            }
            catch (Exception e1)
            {
                MessageBox.Show(e1.Message.ToString());
            }
        }

        private void connect()
        {
            String oradb = "DATA SOURCE=desktop-v82ifm3;PERSIST SECURITY INFO=True;USER ID=system;Password=jarvis07";
            conn = new OracleConnection(oradb);
            c = new OracleCommand();
            c.Connection = conn;
            c.CommandType = CommandType.Text;

            conn.Open();
        }

        private void label26_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
        }

        private void view_Load(object sender, EventArgs e)
        {

        }
    }
}
